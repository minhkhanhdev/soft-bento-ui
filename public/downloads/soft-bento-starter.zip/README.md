# Soft Bento Starter

Source starter: React 19 + HeroUI v3 + Tailwind CSS v4.

```bash
npm install
npm run dev
npm run build
```

Node 20.19+ or 22.12+ is required by Vite 7. Synthetic example data stays in the browser and resets on reload. There is no backend, account or environment setup.

Portable core: src/soft-bento. Optional generic adapters: src/kit.
CSS order: Tailwind, HeroUI, Soft Bento, application layout.
Merge AGENTS.md and DESIGN.md into existing project instructions; do not overwrite them.

This is a source distribution, not a claim of publication on npm. Upstream dependencies keep their own licenses; see https://github.com/minhkhanhdev/soft-bento-ui .
